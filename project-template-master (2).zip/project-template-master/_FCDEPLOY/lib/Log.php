<?php

namespace FatDeploy;

class Log
{
    public static function log($message)
    {
        echo $message . PHP_EOL;
    }
}
